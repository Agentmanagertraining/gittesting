"""
Data validation utilities.
"""
import re


def validate_email(email):
    """
    Validate an email address format.
    
    Args:
        email: Email string to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not isinstance(email, str):
        return False
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_phone(phone):
    """
    Validate a phone number (US format: XXX-XXX-XXXX or XXXXXXXXXX).
    
    Args:
        phone: Phone number string to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not isinstance(phone, str):
        return False
    
    # Remove spaces and dashes
    cleaned = phone.replace('-', '').replace(' ', '')
    
    # Check if it's 10 digits
    return cleaned.isdigit() and len(cleaned) == 10


def validate_password(password):
    """
    Validate password strength.
    Must be at least 8 characters, contain uppercase, lowercase, digit, and special char.
    
    Args:
        password: Password string to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not isinstance(password, str) or len(password) < 8:
        return False
    
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password)
    
    return has_upper and has_lower and has_digit and has_special


def validate_url(url):
    """
    Validate a URL format.
    
    Args:
        url: URL string to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not isinstance(url, str):
        return False
    
    pattern = r'^https?://[^\s/$.?#].[^\s]*$'
    return bool(re.match(pattern, url))


def sanitize_input(text, max_length=100):
    """
    Sanitize user input by removing special characters and limiting length.
    
    Args:
        text: Input text to sanitize
        max_length: Maximum allowed length
        
    Returns:
        Sanitized string
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    # Remove special characters except spaces
    sanitized = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    
    # Limit length
    return sanitized[:max_length].strip()
