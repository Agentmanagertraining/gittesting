"""
User management module for handling user operations.
"""

class User:
    """Represents a user in the system."""
    
    def __init__(self, username, email, age=None):
        """
        Initialize a user.
        
        Args:
            username: User's username (must be non-empty)
            email: User's email address
            age: User's age (optional, must be positive if provided)
        """
        if not username or not username.strip():
            raise ValueError("Username cannot be empty")
        
        if not email or '@' not in email:
            raise ValueError("Invalid email address")
        
        if age is not None and age < 0:
            raise ValueError("Age cannot be negative")
        
        self.username = username.strip()
        self.email = email.strip()
        self.age = age
        self.is_active = True
    
    def deactivate(self):
        """Deactivate the user account."""
        self.is_active = False
    
    def activate(self):
        """Activate the user account."""
        self.is_active = True
    
    def update_email(self, new_email):
        """Update user's email address."""
        if not new_email or '@' not in new_email:
            raise ValueError("Invalid email address")
        self.email = new_email.strip()
    
    def __repr__(self):
        return f"User(username='{self.username}', email='{self.email}', age={self.age})"


class UserManager:
    """Manages a collection of users."""
    
    def __init__(self):
        """Initialize an empty user manager."""
        self.users = {}
    
    def add_user(self, user):
        """
        Add a user to the manager.
        
        Args:
            user: User object to add
            
        Returns:
            True if user was added, False if username already exists
        """
        if user.username in self.users:
            return False
        self.users[user.username] = user
        return True
    
    def get_user(self, username):
        """
        Retrieve a user by username.
        
        Args:
            username: The username to look up
            
        Returns:
            User object if found, None otherwise
        """
        return self.users.get(username)
    
    def remove_user(self, username):
        """
        Remove a user from the manager.
        
        Args:
            username: The username to remove
            
        Returns:
            True if user was removed, False if user doesn't exist
        """
        if username in self.users:
            del self.users[username]
            return True
        return False
    
    def get_active_users(self):
        """Get list of all active users."""
        return [user for user in self.users.values() if user.is_active]
    
    def count_users(self):
        """Get total number of users."""
        return len(self.users)
