"""
String utility functions for text processing.
"""

def reverse_string(text):
    """
    Reverse a string.
    
    Args:
        text: String to reverse
        
    Returns:
        Reversed string
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    return text[::-1]


def is_palindrome(text):
    """
    Check if a string is a palindrome (ignoring case and spaces).
    
    Args:
        text: String to check
        
    Returns:
        True if palindrome, False otherwise
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    cleaned = text.lower().replace(" ", "")
    return cleaned == cleaned[::-1]


def count_words(text):
    """
    Count the number of words in a text.
    
    Args:
        text: String to count words in
        
    Returns:
        Number of words
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    if not text.strip():
        return 0
    
    return len(text.split())


def capitalize_words(text):
    """
    Capitalize the first letter of each word.
    
    Args:
        text: String to capitalize
        
    Returns:
        String with each word capitalized
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    return text.title()


def remove_duplicates(text):
    """
    Remove duplicate characters from a string while preserving order.
    
    Args:
        text: String to process
        
    Returns:
        String with duplicates removed
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    seen = set()
    result = []
    
    for char in text:
        if char not in seen:
            seen.add(char)
            result.append(char)
    
    return ''.join(result)


def find_longest_word(text):
    """
    Find the longest word in a text.
    
    Args:
        text: String to search
        
    Returns:
        Longest word, or None if text is empty
    """
    if not isinstance(text, str):
        raise TypeError("Input must be a string")
    
    words = text.split()
    if not words:
        return None
    
    return max(words, key=len)
