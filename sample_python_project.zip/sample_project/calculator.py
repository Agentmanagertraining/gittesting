"""
Calculator module with basic arithmetic operations.
"""

class Calculator:
    """A simple calculator class with basic operations."""
    
    def add(self, a, b):
        """Add two numbers."""
        return a + b
    
    def subtract(self, a, b):
        """Subtract b from a."""
        return a - b
    
    def multiply(self, a, b):
        """Multiply two numbers."""
        return a * b
    
    def divide(self, a, b):
        """
        Divide a by b.
        Raises ValueError if b is zero.
        """
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b
    
    def power(self, base, exponent):
        """Calculate base raised to the power of exponent."""
        return base ** exponent
    
    def square_root(self, number):
        """
        Calculate square root of a number.
        Raises ValueError if number is negative.
        """
        if number < 0:
            raise ValueError("Cannot calculate square root of negative number")
        return number ** 0.5
