# Sample Python Project

This is a sample Python codebase for testing test case generation tools.

## Modules

### 1. calculator.py
Contains a `Calculator` class with basic arithmetic operations:
- Addition, subtraction, multiplication, division
- Power and square root calculations
- Error handling for invalid operations

### 2. user_manager.py
User management system with two classes:
- `User`: Represents a user with username, email, and age
- `UserManager`: Manages a collection of users

### 3. string_utils.py
String utility functions:
- Reverse string
- Check palindrome
- Count words
- Capitalize words
- Remove duplicates
- Find longest word

### 4. validators.py
Data validation utilities:
- Email validation
- Phone number validation
- Password strength validation
- URL validation
- Input sanitization

## Usage

This codebase is designed to be used for testing automated test case generation tools.
Each module contains various functions and classes with different complexity levels,
edge cases, and error handling scenarios.

## Test Coverage Goals

When generating test cases, aim to cover:
- Normal/happy path scenarios
- Edge cases (empty strings, zero values, None, etc.)
- Error cases (invalid inputs, exceptions)
- Boundary conditions
- Type validation
