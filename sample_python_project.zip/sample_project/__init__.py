"""
Sample Python Project - A collection of modules for testing test generation tools.
"""

__version__ = "1.0.0"
