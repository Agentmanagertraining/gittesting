# Small Test Project

This is a very small project used to test:
- Git repository upload
- Cloning
- Zipping repositories
